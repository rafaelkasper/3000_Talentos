// Isto é um comentário de uma linha

/* 
Isto é um 
comentário 
de várias
linhas
*/

// console.log("Olá mundo!");

// prompt("Qual é o seu nome?");

//const idade = 23;
// let maca = 24;
// maca = 25;
// console.log(maca);

// const nomeCompleto = "Rafael Kasper";

/*
const nome = "Fulana";
const idade = 21;

console.log("Olá!", "Meu nome é ", nome, "e eu tenho", idade, "anos");
*/

/*
const primeiroNome = "Rafael";
const sobrenome = "Kasper";
const idade = 36;
const estudante = false;
console.log(primeiroNome, sobrenome, idade, estudante);
*/

/*
const got = "Game Of Thrones";
const temporadasDeGot = 8;

console.log(typeof got);
console.log(typeof temporadasDeGot);
*/
/*
const nomeUsuario = prompt("Qual é o seu nome?");
console.log(nomeUsuario);
*/

const idade = prompt("Qual é a sua idade?");
console.log(idade);
console.log(typeof idade);
